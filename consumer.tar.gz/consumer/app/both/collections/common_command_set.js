this.CommonCommandSet = new Meteor.Collection("common_command_set");
