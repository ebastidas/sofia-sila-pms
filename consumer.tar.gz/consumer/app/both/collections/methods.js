this.Methods = new Meteor.Collection("methods");
