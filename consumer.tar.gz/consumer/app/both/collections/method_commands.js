this.MethodCommands = new Meteor.Collection("method_commands");
