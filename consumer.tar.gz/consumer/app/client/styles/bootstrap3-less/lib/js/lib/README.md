I put `tooltip.js` into separate folder because it must load before `popover.js`

(if it is in the same dir with `popover.js` then meteor loads `tooltip.js` after `popover.js`)
