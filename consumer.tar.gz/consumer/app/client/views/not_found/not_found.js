Template.notFound.rendered = function() {
	/*TEMPLATE_RENDERED_CODE*/
};

Template.notFound.events({

});

Template.notFound.helpers({

});
