Template.Logout.rendered = function() {
	
};

Template.Logout.events({
	
});

Template.Logout.helpers({
	
});
