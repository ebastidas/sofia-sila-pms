var pageSession = new ReactiveDict();

Template.DevicesEdit.rendered = function() {
	
};

Template.DevicesEdit.events({
	
});

Template.DevicesEdit.helpers({
	
});

Template.DevicesEditEditForm.rendered = function() {
	

	pageSession.set("devicesEditEditFormInfoMessage", "");
	pageSession.set("devicesEditEditFormErrorMessage", "");

	$(".input-group.date").each(function() {
		var format = $(this).find("input[type='text']").attr("data-format");

		if(format) {
			format = format.toLowerCase();			
		}
		else {
			format = "mm/dd/yyyy";
		}

		$(this).datepicker({
			autoclose: true,
			todayHighlight: true,
			todayBtn: true,
			forceParse: false,
			keyboardNavigation: false,
			format: format
		});
	});

	$("input[autofocus]").focus();
};

Template.DevicesEditEditForm.events({
	"submit": function(e, t) {
		e.preventDefault();
		pageSession.set("devicesEditEditFormInfoMessage", "");
		pageSession.set("devicesEditEditFormErrorMessage", "");
		
		var self = this;

		function submitAction(msg) {
			if(!t.find("#form-cancel-button")) {
				var message = msg || "Saved.";
				pageSession.set("devicesEditEditFormInfoMessage", message);
			}

			Router.go("devices", {});
		}

		function errorAction(msg) {
			var message = msg || "Error.";
			pageSession.set("devicesEditEditFormErrorMessage", message);
		}

		validateForm(
			$(e.target),
			function(fieldName, fieldValue) {

			},
			function(msg) {

			},
			function(values) {
				

				Devices.update({ _id: t.data.device._id }, { $set: values }, function(e) { if(e) errorAction(e.message); else submitAction(); });
			}
		);

		return false;
	},
	"click #form-cancel-button": function(e, t) {
		e.preventDefault();

		

		Router.go("devices", {});
	},
	"click #form-close-button": function(e, t) {
		e.preventDefault();

		/*CLOSE_REDIRECT*/
	},
	"click #form-back-button": function(e, t) {
		e.preventDefault();

		/*BACK_REDIRECT*/
	}

	
});

Template.DevicesEditEditForm.helpers({
	"infoMessage": function() {
		return pageSession.get("devicesEditEditFormInfoMessage");
	},
	"errorMessage": function() {
		return pageSession.get("devicesEditEditFormErrorMessage");
	}
	
});
