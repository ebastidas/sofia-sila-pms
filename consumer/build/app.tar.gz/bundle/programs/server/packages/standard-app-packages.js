(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['standard-app-packages'] = {};

})();

//# sourceMappingURL=standard-app-packages.js.map
