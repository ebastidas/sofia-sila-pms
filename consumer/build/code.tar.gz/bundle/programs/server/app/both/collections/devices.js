(function(){this.Devices = new Meteor.Collection("devices");

})();
