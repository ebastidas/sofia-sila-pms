(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['mizzao:bootboxjs'] = {};

})();

//# sourceMappingURL=mizzao_bootboxjs.js.map
